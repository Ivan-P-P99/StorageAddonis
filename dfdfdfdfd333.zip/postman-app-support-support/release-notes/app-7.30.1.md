## Postman v7.30.1

### Bug Fix
* Fixed an issue where Send Request shortcut was not working while navigating requests in the sidebar
[#8909](https://github.com/postmanlabs/postman-app-support/issues/8909)
