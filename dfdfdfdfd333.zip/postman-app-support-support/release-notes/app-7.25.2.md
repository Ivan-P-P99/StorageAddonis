## Postman v7.25.2

### What's New

* We now support the latest security protocol TLS v1.3 for your APIs
[#5628](https://github.com/postmanlabs/postman-app-support/issues/5628)

### Bug Fixes

* Fixed an issue where requests being sent to servers running on TLS v1.0 or v1.1 were failing [#8565](https://github.com/postmanlabs/postman-app-support/issues/8565)
