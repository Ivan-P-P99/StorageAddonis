"""
Doctests:

>>> 1 == 1
True
"""
