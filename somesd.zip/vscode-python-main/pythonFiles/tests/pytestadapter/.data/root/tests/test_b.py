# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.


def test_b_function():  # test_marker--test_b_function
    assert True
