# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.


# This test passes.
def test_function():  # test_marker--test_function
    assert 1 == 1
