---
name: Feature request
about: Request for the Python extension, not supporting/sibling extensions
labels: classify, feature-request
---

<!-- **PLEASE** look for preexisting feature requests before opening a new one as a 👍 on a preexisting issue is more important than opening a new issue or leaving a comment. -->
